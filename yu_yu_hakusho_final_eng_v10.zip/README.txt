YU YU HAKUSHO FINAL: MAKAI SAIKYOU RETSUDEN
English Translation v1.0 (v10)
By Retch
October 16, 2026

============================================================
ABOUT
============================================================
An English translation and presentation polish patch for
Yu Yu Hakusho Final: Makai Saikyou Retsuden on Super Famicom.

This patch translates the game's major menus, story dialogue,
fighter and technique names, battle announcements, result text,
and ending credits. It also refines the English typography and
menu presentation while retaining the original game's look,
combat mechanics, music, and Japanese voice performances.

============================================================
VERSION 1.0 (v10) CHANGELOG
============================================================
- Translated the main menu, game modes, and gameplay interface.
- Centered the eight main-menu labels more consistently,
  including STORY MODE, without disrupting TEAM or TRAINING.
- Refined the Story dialogue capitals to match the original
  SNES pixel lettering, stroke weight, and character spacing.
- Redrew uneven capital A, I, J, and T shapes for a cleaner,
  more consistent English dialogue typeface.
- Preserved original lowercase letters, punctuation, and text
  layout without stretching or replacing the native font.
- Improved typography and readability in Story Mode.
- Translated and refined Story dialogue and speaker names.
- Corrected eleven Story entries for meaning, context, and
  character attribution.
- Translated forty battle-result quotations.
- Translated character, fighter, and technique labels.
- Redesigned all thirteen battle HUD name graphics as clean,
  centered single-line labels, including YUSUKE, SENSUI,
  KUWABARA, SHIGURE, HIEI, and MUKURO.
- Refined special-move command glyphs so CHG and the Heavy
  move-button labels use matching full-size English lettering.
- Refined pixel spacing and proportions within the original
  HUD and command-display dimensions without changing combat.
- Translated battle START and the tournament round announcements:
  1ST MATCH, 2ND MATCH, FINAL MATCH, RE MATCH, and DRAW.
- Translated the tournament results, including THE WINNER,
  WINNER, and LOSER.
- Improved English fighter and team-selection text.
- Translated and reformatted five ending-credits pages while
  preserving the original creator and staff attributions.
- Retained the original Japanese title artwork, soundtrack,
  voice acting, and the game's balance and gameplay behavior.

This is a cumulative patch. Previous translation patches
are not required and should not be applied together with it.

============================================================
INSTALLATION
============================================================
Game: Yu Yu Hakusho Final: Makai Saikyou Retsuden
Platform: Super Famicom / SNES
ROM: Clean, unheadered Japanese original (3,145,728 bytes)
Patch format: IPS
Recommended emulator: bsnes

1. Back up your original Japanese game ROM.
2. Open Floating IPS (Flips) or another IPS patching utility.
3. Select yu_yu_hakusho_final_eng_v10.ips.
4. Apply it to a CLEAN, UNPATCHED Japanese ROM.
5. Run the patched game in bsnes (recommended), another
   compatible SNES emulator, or compatible hardware.

Do not apply this patch to an already translated or modified ROM.
If you have used an older version, start again with the clean
Japanese original.

============================================================
NOTES
============================================================
The Japanese title logo and original spoken dialogue are
intentionally preserved as part of the game's identity.
The original music, character artwork, legal attributions,
and game balance are also retained.

Only a translation patch is distributed. No copyrighted
game ROM is included. You must supply your own legally
obtained copy of the original game.

============================================================
CREDITS
============================================================
English Translation, ROM Hack, and Presentation: Retch
Original Game: Namco and the Yu Yu Hakusho Final development team
Original Manga: Yoshihiro Togashi

This is an unofficial, noncommercial fan translation.
It is not affiliated with or endorsed by the rights holders.

By Retch
