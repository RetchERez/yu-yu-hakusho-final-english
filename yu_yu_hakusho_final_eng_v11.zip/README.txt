YU YU HAKUSHO FINAL: MAKAI SAIKYOU RETSUDEN
English Translation v1.1
By Retch
November 2026

============================================================
ABOUT
============================================================
An English translation and presentation polish patch for
Yu Yu Hakusho Final: Makai Saikyou Retsuden on Super Famicom.

The patch translates the menus, story dialogue, fighter and
technique names, move lists, battle announcements, result
quotes, tournament screens, title screen and ending credits,
while keeping the original game's look, combat, music and
Japanese voice performances.

============================================================
VERSION 1.1 CHANGELOG
============================================================
New font
- New proportional serif font for all in-game text, drawn in
  the style of the game's own lettering
- Letters now take only the width they need, so lines read
  naturally instead of in fixed 8-pixel steps
- Capital I and lowercase l are easy to tell apart

Title screen
- English title logo: YU YU HAKUSHO with the original FINAL,
  in the same red, white and blue style and colors
- English subtitle plate and English copyright lines

Story
- All 71 story pages re-set with the new font and rewrapped
  with balanced lines; short sentences get their own line
- Fixed words that ran together at line breaks (hasalready,
  hopeto, fornow, leftfor, powerlevels, World'sthree, helphim)
- Small grammar fixes on five pages
- Curly quotes and apostrophes

Menus and screens
- Main menu, Options, Controls, Training, mode select, Pick
  Fighter, Pick Team and team labels redone in one font with
  consistent alignment
- Fixed the EASY and NORMAL difficulty names, which showed
  as garbled letters
- Option values (ON, OFF, STEREO, MONO) and the sound test
  counters use the new font; SOUND MODE is now OUTPUT MODE
- Controls read LO PUNCH, HI PUNCH, LO KICK and HI KICK at
  full size
- Continue screen and the post-fight score tally redone; every
  number on screen now uses the same digits

Move lists
- All 14 move lists redone with the new font; the game's own
  arrow icons are kept
- Fixed corrupted move names: Gatling Stomp, Machine Gun
  Knuckle, Radiant Fist, Radiant Strike, Spirit Cannon, Ring
  Storm, Nether Blast, Energy Strike, Leaf Storm
- Added missing details: Double Red Ball Shot, Air Spirit Gun
  (in the air), Twin Dragons (life 1/10)
- Button labels (P, K, HP, HK, CHG, MASH) redrawn

Battles and tournament
- All 40 battle-result quotes re-set in sentence case and
  wrapped to fit the box
- Demon Tournament bracket round names translated (ROUND 1,
  ROUND 2, ROUND 3, FINAL)
- Tournament ranks, match labels, total points and the
  tournament ending line translated
- Victory lines that were still in Japanese now use the
  English story lines

Ending credits
- Credits redrawn with a clean font (proper A and S)
- Dual roles marked as YUSUKE/MAJIN and KURAMA/YOKO

============================================================
VERSION 1.0 (v10) CHANGELOG
============================================================
- Translated the main menu, game modes, and gameplay interface
- Translated Story dialogue and speaker names
- Translated forty battle-result quotations
- Translated character, fighter, and technique labels
- Redesigned all thirteen battle HUD name graphics as clean,
  centered single-line labels
- Translated battle START and the tournament round
  announcements: 1ST MATCH, 2ND MATCH, FINAL MATCH, RE MATCH,
  and DRAW
- Translated the tournament results, including THE WINNER,
  WINNER, and LOSER
- Translated and reformatted five ending-credits pages while
  preserving the original creator and staff attributions

This is a cumulative patch. Apply it to a clean Japanese ROM;
do not apply it on top of v1.0.

============================================================
INSTALLATION
============================================================
Game: Yu Yu Hakusho Final: Makai Saikyou Retsuden
Platform: Super Famicom / SNES
ROM: Clean, unheadered Japanese original (3,145,728 bytes)
Patch format: IPS
Recommended emulator: bsnes

1. Back up your original Japanese game ROM.
2. Open Floating IPS (Flips) or another IPS patching utility.
3. Select yu_yu_hakusho_final_eng_v11.ips.
4. Apply it to a CLEAN, UNPATCHED Japanese ROM.
5. Run the patched game in bsnes (recommended), another
   compatible SNES emulator, or compatible hardware.

The patched ROM is 4 MB (4,194,304 bytes); the extra space
holds the new text graphics. The header already declares
4 MB, so no other change is needed.

============================================================
NOTES
============================================================
The original music, voice acting, character artwork, legal
attributions and game balance are retained. Combat and game
logic are unchanged.

Staff names in the ending credits are kept exactly as in
v1.0.

Only a translation patch is distributed. No copyrighted
game ROM is included. You must supply your own legally
obtained copy of the original game.

============================================================
CREDITS
============================================================
English Translation, ROM Hack, and Presentation: Retch
Original Game: Namco and the Yu Yu Hakusho Final development team
Original Manga: Yoshihiro Togashi

This is an unofficial, noncommercial fan translation.
It is not affiliated with or endorsed by the rights holders.

By Retch
